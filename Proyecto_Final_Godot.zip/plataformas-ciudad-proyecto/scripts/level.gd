extends Node3D

# Controls the flow of a playable level: watches how many enemies are
# currently alive, reacts to the player dying, and shows/hides the
# defeat & victory screens. Also handles moving on to the next level.

@export_subgroup("Level progression")
@export var next_level_path: String = "" # Leave empty on the last level of the campaign

@onready var player = $Player
@onready var enemies = $Enemies
@onready var defeat_screen = $DefeatScreen
@onready var victory_screen = $VictoryScreen
@onready var victory_label = $VictoryScreen/CenterContainer/VBoxContainer/Label
@onready var continue_button = $VictoryScreen/CenterContainer/VBoxContainer/ButtonContainer/ContinueButton

var enemies_defeated_once := {} # Set of enemies (node -> true) that have been eliminated at least once
var total_enemies := 0
var game_over := false

func _ready():
	player.died.connect(_on_player_died)

	total_enemies = enemies.get_child_count()

	for enemy in enemies.get_children():
		if enemy.has_signal("defeated"):
			enemy.defeated.connect(_on_enemy_defeated)

	# Adjust the victory screen depending on whether there's a next level
	if next_level_path == "":
		continue_button.text = "JUGAR DE NUEVO"
		victory_label.text = "¡JUEGO COMPLETADO!"
	else:
		continue_button.text = "SIGUIENTE NIVEL"

# Called every time any enemy is destroyed. Victory is won once every enemy in
# the level has been eliminated (enemies no longer respawn, so this is the
# same as clearing them all).

func _on_enemy_defeated(enemy):
	if game_over:
		return

	enemies_defeated_once[enemy] = true

	if enemies_defeated_once.size() >= total_enemies:
		_show_end_screen(victory_screen, "sounds/weapon_change.ogg")

# Called when the player runs out of health or falls off the level

func _on_player_died():
	_show_end_screen(defeat_screen, "sounds/enemy_destroy.ogg")

# Shared logic for showing either end-of-level screen

func _show_end_screen(screen: CanvasLayer, sound: String) -> void:
	if game_over:
		return

	game_over = true

	Audio.play(sound)

	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().paused = true # Stops the player and every enemy from moving

	screen.visible = true

# Button handlers (connected from DefeatScreen/VictoryScreen in the scene)

func _retry_level():
	get_tree().paused = false
	get_tree().reload_current_scene() # Fresh copy of the level: player, enemies and everything else reset

func _continue_after_victory():
	get_tree().paused = false

	if next_level_path == "":
		get_tree().change_scene_to_file("res://scenes/level1.tscn") # Last level: start the campaign over
	else:
		get_tree().change_scene_to_file(next_level_path)

func _go_to_main_menu():
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/main.tscn")
