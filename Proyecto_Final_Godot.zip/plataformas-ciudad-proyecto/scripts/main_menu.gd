extends Control

@onready var quit_button: Button = $MenuFrame/Background/Buttons/QuitButton
@onready var play_button: Button = $MenuFrame/Background/Buttons/PlayButton
@onready var main_content: Control = $MenuFrame/Background/Buttons
@onready var controls_menu: Control = $ControlsMenu

func _ready():
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

	play_button.grab_focus()

	# Quitting isn't meaningful in web exports, so hide the button there
	if OS.has_feature("web"):
		quit_button.visible = false

func _on_play_button_pressed():
	get_tree().change_scene_to_file("res://scenes/level1.tscn")

func _on_quit_button_pressed():
	get_tree().quit()

# Muestra la pantalla de controles encima del menú
func _on_controls_button_pressed():
	main_content.visible = false
	controls_menu.open()

func _on_controls_back_pressed():
	controls_menu.visible = false
	main_content.visible = true
	play_button.grab_focus()
