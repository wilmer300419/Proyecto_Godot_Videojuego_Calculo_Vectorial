extends Control

# Pantalla "CONTROLES". Se muestra desde el menú principal y emite 'back_pressed'
# al pulsar VOLVER (o Escape). Las teclas se leen del Input Map, así que si se
# cambian allí la pantalla se actualiza sola.

signal back_pressed

const FONT := preload("res://fonts/lilita_one_regular.ttf")

const COLOR_TEXT := Color(0.176471, 0.176471, 0.203922, 1)
const COLOR_PURPLE := Color(0.65098, 0.32549, 0.94902, 1)
const COLOR_PURPLE_DARK := Color(0.482353, 0.203922, 0.788235, 1)

# Cada sección: título y lista de [acción del Input Map, texto]
const SECTIONS := [
	["MOVIMIENTO", [
		["move_forward", "Adelante"],
		["move_back", "Atrás"],
		["move_left", "Izquierda"],
		["move_right", "Derecha"],
		["jump", "Saltar"],
		["sprint", "Correr"],
	]],
	["COMBATE", [
		["aim", "Apuntar"],
		["shoot", "Disparar"],
		["melee", "Cuerpo a cuerpo"],
		["reload", "Recargar"],
	]],
	["ARMAS", [
		["weapon_mg", "Metralleta"],
		["weapon_revolver", "Revólver"],
		["weapon_shotgun", "Escopeta"],
		["weapon_toggle", "Siguiente arma"],
	]],
	["BRAZOS", [
		["arm_left", "Brazo izquierdo"],
		["arm_right", "Brazo derecho"],
		["arm_both", "Ambos brazos"],
	]],
]

@onready var sections_grid: GridContainer = $CenterContainer/VBoxContainer/SectionsGrid
@onready var back_button: Button = $CenterContainer/VBoxContainer/BackButton

func _ready() -> void:
	back_button.pressed.connect(func(): back_pressed.emit())

	for section in SECTIONS:
		sections_grid.add_child(_make_section(section[0], section[1]))

func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		back_pressed.emit()

func open() -> void:
	visible = true
	back_button.grab_focus()

func _make_section(title: String, rows: Array) -> PanelContainer:
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.size_flags_vertical = Control.SIZE_FILL

	var box := StyleBoxFlat.new()
	box.bg_color = Color(1, 1, 1, 0.75)
	box.set_corner_radius_all(20)
	box.content_margin_left = 24
	box.content_margin_right = 24
	box.content_margin_top = 10
	box.content_margin_bottom = 14
	panel.add_theme_stylebox_override("panel", box)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 6)
	panel.add_child(column)

	var header := Label.new()
	header.text = title
	_style_label(header, 30, COLOR_PURPLE_DARK)
	column.add_child(header)

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 18)
	grid.add_theme_constant_override("v_separation", 6)
	column.add_child(grid)

	for row in rows:
		grid.add_child(_make_key_cap(_keys_text(row[0])))

		var description := Label.new()
		description.text = row[1]
		description.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		_style_label(description, 24, COLOR_TEXT)
		grid.add_child(description)

	return panel

func _make_key_cap(text: String) -> PanelContainer:
	var cap := PanelContainer.new()
	cap.custom_minimum_size = Vector2(190, 0)
	cap.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN

	var box := StyleBoxFlat.new()
	box.bg_color = COLOR_PURPLE
	box.border_color = COLOR_PURPLE_DARK
	box.border_width_bottom = 4
	box.set_corner_radius_all(10)
	box.content_margin_left = 14
	box.content_margin_right = 14
	box.content_margin_top = 2
	box.content_margin_bottom = 4
	cap.add_theme_stylebox_override("panel", box)

	var label := Label.new()
	label.text = text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_style_label(label, 22, Color.WHITE)
	cap.add_child(label)

	return cap

func _style_label(label: Label, size: int, color: Color) -> void:
	label.add_theme_font_override("font", FONT)
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)

# Teclas y botones del ratón de una acción (se ignoran los mandos)
func _keys_text(action: String) -> String:
	var names: Array[String] = []

	for event in InputMap.action_get_events(action):
		if event is InputEventKey:
			var key: int = event.physical_keycode if event.physical_keycode != KEY_NONE else event.keycode
			names.append(OS.get_keycode_string(key).to_upper())
		elif event is InputEventMouseButton:
			match event.button_index:
				MOUSE_BUTTON_LEFT: names.append("CLIC IZQUIERDO")
				MOUSE_BUTTON_RIGHT: names.append("CLIC DERECHO")
				MOUSE_BUTTON_MIDDLE: names.append("CLIC CENTRAL")

	return " / ".join(names) if not names.is_empty() else "—"
