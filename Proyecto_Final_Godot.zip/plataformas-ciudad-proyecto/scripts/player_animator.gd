class_name PlayerAnimator
extends Node

# Controla TODAS las animaciones del modelo Player.glb con un AnimationTree que se
# construye por código al iniciar (así los nombres de clips y huesos viven en un
# solo sitio y no dependen de editar un recurso a mano).
#
# Capas, de abajo hacia arriba (cada una se apoya en la anterior):
#
#   1. LOCOMOCIÓN        BlendSpace2D con las 8 direcciones + "Stand Still".
#   2. APUNTADO          Mezcla con la misma locomoción, pero con las variantes
#                        "Aiming Left Arm ...". Estas variantes son caminatas de
#                        cuerpo completo (las piernas son idénticas a las normales),
#                        así que mezclarlas solo cambia el brazo/torso.
#   3. SALTO / HOP       Cuerpo completo. Jump = primer salto, Hop = salto doble.
#   4. BRAZOS Y TORSO    Disparo, recarga y cuerpo a cuerpo. Se aplican SOLO a los
#                        huesos de la columna hacia arriba (torso + brazos), de modo
#                        que las piernas siguen con la locomoción de la capa 1.
#   5. MUERTE            Cuerpo completo; se queda en el último fotograma.
#
# Uso desde el jugador (ver objects/player.gd):
#   update_locomotion(), set_aiming(), play_jump(), play_upper(), play_death()...

signal upper_action_finished # Terminó el clip de brazos/torso (disparo, recarga, melee)

enum Arm { LEFT, RIGHT, BOTH }

## Nodo raíz del modelo importado (el que contiene AnimationPlayer y Skeleton3D).
@export var model_root: Node

@export_subgroup("Mezcla")
## Rapidez con la que se entra/sale de la pose de apuntado.
@export var aim_blend_speed: float = 9.0
## Suavizado de la dirección de caminata (más alto = responde más rápido).
@export var locomotion_smoothing: float = 14.0
## Velocidad de reproducción de la caminata al correr (Shift).
@export var sprint_time_scale: float = 1.5
## Duración (s) con la que se estira Jump/Hop. Se ajusta con set_air_time().
@export var air_time: float = 0.8

# Hueso desde el que se aplican las animaciones de brazos/torso (columna).
# Todo lo que cuelga de él (pecho, brazos, cañones) forma la "parte superior".
# Caderas, piernas y raíz quedan fuera.
const UPPER_BODY_ROOT_PREFIX := "Torso.009"

const DIRECTIONS := {
	"Forward": Vector2(0, 1),
	"Backward": Vector2(0, -1),
	"Left": Vector2(-1, 0),
	"Right": Vector2(1, 0),
	"Forward Left": Vector2(-1, 1),
	"Forward Right": Vector2(1, 1),
	"Backward Left": Vector2(-1, -1),
	"Backward Right": Vector2(1, -1),
}

const WEAPON_CLIP_NAMES := {
	Weapon.Type.MG: "MG",
	Weapon.Type.REVOLVER: "Revolver",
	Weapon.Type.SHOTGUN: "Shotgun",
}

const ARM_NAMES := { Arm.LEFT: "Left", Arm.RIGHT: "Right" }

const CLIP_STAND := &"Stand Still"
const CLIP_STAND_AIM := &"Aiming Left Arm Stand Still"
const CLIP_JUMP := &"Jump"
const CLIP_HOP := &"Hop"
const CLIP_CYCLIC := &"Cyclic" # Disponible en el árbol, sin asignar a ninguna acción
const CLIPS_DEATH: Array[StringName] = [&"Death A", &"Death B"]

# El clip de revólver dura 10 s y contiene 8 disparos seguidos (uno cada ~1.29 s).
# Para un disparo por clic solo se reproduce la primera ventana.
const REVOLVER_SHOT_WINDOW := 1.2917
# Para "congelar" la muerte en su último fotograma el nodo se deja correr mucho
# más allá de la duración del clip.
const HOLD_FOREVER := 3600.0

var animation_player: AnimationPlayer
var skeleton: Skeleton3D
var tree: AnimationTree

var _aim_target := 0.0
var _aim_amount := 0.0
var _move_blend := Vector2.ZERO
var _held_clip: StringName = &""
var _upper_was_active := false
var _upper_clips: Array[StringName] = []
var _jump_node: AnimationNodeAnimation
var _hop_node: AnimationNodeAnimation

func _ready() -> void:
	if model_root == null:
		push_error("PlayerAnimator: falta asignar 'model_root' (el modelo Player.glb).")
		return

	animation_player = model_root.find_child("AnimationPlayer", true, false)
	skeleton = model_root.find_child("Skeleton3D", true, false)

	if animation_player == null or skeleton == null:
		push_error("PlayerAnimator: el modelo no contiene AnimationPlayer/Skeleton3D.")
		return

	_make_loops()
	_make_tree()

# --- API pública -------------------------------------------------------------

# move_vector: dirección de movimiento relativa al cuerpo, x = derecha, y = adelante,
# con longitud 0..1 (1 = velocidad de caminata normal).
func update_locomotion(move_vector: Vector2, sprinting: bool, delta: float) -> void:
	if tree == null:
		return

	var target := move_vector.limit_length(1.0)

	if target.length() < 0.1:
		target = Vector2.ZERO # Quieto: Stand Still puro, sin restos de caminata

	_move_blend = _move_blend.lerp(target, 1.0 - exp(-locomotion_smoothing * delta))

	tree.set("parameters/walk/blend_position", _move_blend)
	tree.set("parameters/aim/blend_position", _move_blend)
	tree.set("parameters/loco_speed/scale", sprint_time_scale if sprinting else 1.0)

	_aim_amount = move_toward(_aim_amount, _aim_target, aim_blend_speed * delta)
	tree.set("parameters/aim_mix/blend_amount", _aim_amount)

	var upper_active: bool = tree.get("parameters/upper_shot/active")

	if _upper_was_active and not upper_active:
		upper_action_finished.emit()

	_upper_was_active = upper_active

func set_aiming(aiming: bool) -> void:
	_aim_target = 1.0 if aiming else 0.0

# Duración real del salto en el aire (2 * velocidad inicial / gravedad). Jump y Hop
# se estiran para durar lo mismo que el salto físico.
func set_air_time(seconds: float) -> void:
	air_time = maxf(seconds, 0.2)

	if _jump_node:
		_jump_node.timeline_length = air_time
		_hop_node.timeline_length = air_time

func play_jump(double_jump: bool) -> void:
	if tree == null:
		return

	_fire(&"hop_shot" if double_jump else &"jump_shot")

# Clip de brazos/torso (disparo, recarga, melee). Con loop = true el clip se repite
# mientras no se llame a release_upper() (fuego automático de la metralleta).
func play_upper(clip: StringName, loop := false) -> void:
	if tree == null:
		return

	if not _upper_clips.has(clip):
		push_warning("PlayerAnimator: el clip '%s' no está en la capa de brazos." % clip)
		return

	if loop and _held_clip == clip and tree.get("parameters/upper_shot/active"):
		return # Ya está sonando en bucle: no reiniciar

	tree.set("parameters/upper_clip/transition_request", String(clip))
	_fire(&"upper_shot")
	_held_clip = clip if loop else &""

# Suelta el clip en bucle (fuego automático). No toca recargas ni melee, así que es
# seguro llamarla en cada frame mientras no se pulsa el gatillo.
func release_upper() -> void:
	if tree == null or _held_clip == &"":
		return

	stop_upper()

# Corta con suavidad el clip de brazos/torso que esté sonando, sea el que sea.
func stop_upper() -> void:
	if tree == null:
		return

	_held_clip = &""

	if tree.get("parameters/upper_shot/active"):
		tree.set("parameters/upper_shot/request", AnimationNodeOneShot.ONE_SHOT_REQUEST_FADE_OUT)

func is_upper_active() -> bool:
	return tree != null and tree.get("parameters/upper_shot/active")

# Reproduce la muerte (0 = Death A, 1 = Death B). Devuelve su duración en segundos.
func play_death(variant: int) -> float:
	if tree == null:
		return 0.0

	var clip: StringName = CLIPS_DEATH[variant % CLIPS_DEATH.size()]

	tree.set("parameters/death_clip/transition_request", String(clip))
	_fire(&"death_shot")

	return get_clip_length(clip)

func get_clip_length(clip: StringName) -> float:
	if animation_player == null or not animation_player.has_animation(clip):
		return 0.0

	var length := animation_player.get_animation(clip).length

	if clip.begins_with("Shooting") and clip.contains("Revolver"):
		return minf(length, REVOLVER_SHOT_WINDOW)

	return length

# Nombres de clip según el arma y el brazo ----------------------------------

static func shoot_clip(weapon_type: Weapon.Type, arm: Arm) -> StringName:
	var weapon_name: String = WEAPON_CLIP_NAMES[weapon_type]

	if arm == Arm.BOTH:
		return StringName("Shooting Dual %s" % weapon_name)

	return StringName("Shooting %s Arm %s" % [ARM_NAMES[arm], weapon_name])

static func reload_clip(arm: Arm) -> StringName:
	return StringName("Reloading %s Arm Shotgun" % ARM_NAMES[arm])

static func melee_clip(arm: Arm, variant_b: bool) -> StringName:
	return StringName("Melee Simple Bash %s Arm %s" % [ARM_NAMES[arm], "B" if variant_b else "A"])

# --- Construcción del árbol --------------------------------------------------

# Las animaciones importadas de un .glb no hacen bucle por defecto.
func _make_loops() -> void:
	var looping: Array[StringName] = [CLIP_STAND, CLIP_STAND_AIM]

	for direction in DIRECTIONS:
		looping.append(StringName("Walk Cycle %s" % direction))
		looping.append(StringName("Aiming Left Arm Walk Cycle %s" % direction))

	for weapon_name in ["MG"]:
		for side in ["Left Arm", "Right Arm", "Dual"]:
			looping.append(StringName("Shooting %s %s" % [side, weapon_name]))

	for clip in looping:
		if animation_player.has_animation(clip):
			animation_player.get_animation(clip).loop_mode = Animation.LOOP_LINEAR
		else:
			push_warning("PlayerAnimator: falta el clip '%s'." % clip)

func _make_tree() -> void:
	var graph := AnimationNodeBlendTree.new()

	# 1 + 2. Locomoción normal y con apuntado, mezcladas por "aim_mix".
	graph.add_node(&"walk", _make_blend_space("Walk Cycle %s", CLIP_STAND))
	graph.add_node(&"aim", _make_blend_space("Aiming Left Arm Walk Cycle %s", CLIP_STAND_AIM))

	var aim_mix := AnimationNodeBlend2.new()
	aim_mix.sync = true # Ambas caminatas avanzan a la vez, aunque una pese 0
	graph.add_node(&"aim_mix", aim_mix)
	graph.connect_node(&"aim_mix", 0, &"walk")
	graph.connect_node(&"aim_mix", 1, &"aim")

	graph.add_node(&"loco_speed", AnimationNodeTimeScale.new())
	graph.connect_node(&"loco_speed", 0, &"aim_mix")

	# 3. Salto (cuerpo completo).
	_jump_node = _make_clip_node(CLIP_JUMP)
	_hop_node = _make_clip_node(CLIP_HOP)

	for stretched in [_jump_node, _hop_node]:
		stretched.use_custom_timeline = true
		stretched.timeline_length = air_time
		stretched.stretch_time_scale = true
		stretched.loop_mode = Animation.LOOP_NONE

	graph.add_node(&"jump_clip", _jump_node)
	graph.add_node(&"hop_clip", _hop_node)
	_add_one_shot(graph, &"jump_shot", &"loco_speed", &"jump_clip", 0.08, 0.2)
	_add_one_shot(graph, &"hop_shot", &"jump_shot", &"hop_clip", 0.08, 0.2)

	# 4. Brazos y torso: un Transition elige el clip y un OneShot filtrado lo aplica.
	var upper_names: Array[StringName] = []

	for weapon_type in WEAPON_CLIP_NAMES:
		for arm in [Arm.LEFT, Arm.RIGHT, Arm.BOTH]:
			upper_names.append(shoot_clip(weapon_type, arm))

	for arm in [Arm.LEFT, Arm.RIGHT]:
		upper_names.append(reload_clip(arm))

		for variant_b in [false, true]:
			upper_names.append(melee_clip(arm, variant_b))

	upper_names.append(CLIP_CYCLIC)
	_upper_clips = upper_names

	_add_clip_selector(graph, &"upper_clip", upper_names, false)
	var upper := _add_one_shot(graph, &"upper_shot", &"hop_shot", &"upper_clip", 0.08, 0.15)
	upper.filter_enabled = true

	for path in _upper_body_paths(upper_names):
		upper.set_filter_path(path, true)

	# 5. Muerte (cuerpo completo, se queda en el último fotograma).
	var death_names: Array[StringName] = CLIPS_DEATH.duplicate()

	_add_clip_selector(graph, &"death_clip", death_names, true)
	_add_one_shot(graph, &"death_shot", &"upper_shot", &"death_clip", 0.12, 0.0)

	graph.connect_node(&"output", 0, &"death_shot")

	# AnimationTree hermano del AnimationPlayer: comparten la misma raíz de rutas.
	tree = AnimationTree.new()
	tree.name = &"AnimationTree"
	animation_player.get_parent().add_child(tree)
	tree.anim_player = tree.get_path_to(animation_player)
	tree.tree_root = graph
	tree.active = true

func _make_blend_space(pattern: String, idle_clip: StringName) -> AnimationNodeBlendSpace2D:
	var space := AnimationNodeBlendSpace2D.new()
	space.min_space = Vector2(-1, -1)
	space.max_space = Vector2(1, 1)
	space.sync = true

	space.add_blend_point(_make_clip_node(idle_clip), Vector2.ZERO, -1, idle_clip)

	for direction in DIRECTIONS:
		var point: Vector2 = DIRECTIONS[direction]
		var clip := StringName(pattern % direction)
		space.add_blend_point(_make_clip_node(clip), point.normalized(), -1, clip)

	return space

func _make_clip_node(clip: StringName) -> AnimationNodeAnimation:
	var node := AnimationNodeAnimation.new()
	node.animation = clip
	return node

# Transition con un clip por entrada. hold = true deja el clip en su último fotograma.
func _add_clip_selector(graph: AnimationNodeBlendTree, node_name: StringName, clips: Array[StringName], hold: bool) -> void:
	var selector := AnimationNodeTransition.new()
	selector.input_count = clips.size()
	selector.xfade_time = 0.0
	selector.allow_transition_to_self = true
	graph.add_node(node_name, selector)

	for i in clips.size():
		var clip := clips[i]
		var clip_node := _make_clip_node(clip)

		# OJO: stretch_time_scale vale true por defecto y estiraría el clip hasta
		# timeline_length. Aquí se quiere velocidad normal, así que se desactiva.
		if hold:
			clip_node.use_custom_timeline = true
			clip_node.timeline_length = HOLD_FOREVER
			clip_node.stretch_time_scale = false
			clip_node.loop_mode = Animation.LOOP_NONE
		elif clip.begins_with("Shooting") and clip.contains("Revolver"):
			clip_node.use_custom_timeline = true
			clip_node.timeline_length = REVOLVER_SHOT_WINDOW
			clip_node.stretch_time_scale = false
			clip_node.loop_mode = Animation.LOOP_NONE

		var clip_node_name := StringName("%s_%d" % [node_name, i])
		graph.add_node(clip_node_name, clip_node)
		graph.connect_node(node_name, i, clip_node_name)
		selector.set_input_name(i, String(clip))

func _add_one_shot(graph: AnimationNodeBlendTree, node_name: StringName, base: StringName, shot: StringName, fade_in: float, fade_out: float) -> AnimationNodeOneShot:
	var one_shot := AnimationNodeOneShot.new()
	one_shot.fadein_time = fade_in
	one_shot.fadeout_time = fade_out

	graph.add_node(node_name, one_shot)
	graph.connect_node(node_name, 0, base)
	graph.connect_node(node_name, 1, shot)

	return one_shot

# Rutas de pista (p. ej. "Skeleton3D:Arm.L_044") de todos los huesos que cuelgan de
# la columna. Se toman de las pistas reales de las animaciones para que coincidan
# exactamente con lo que importó Godot.
func _upper_body_paths(clips: Array[StringName]) -> Array[NodePath]:
	var upper_bones := {}
	var root_bone := -1

	for i in skeleton.get_bone_count():
		if skeleton.get_bone_name(i).begins_with(UPPER_BODY_ROOT_PREFIX):
			root_bone = i
			break

	if root_bone == -1:
		push_error("PlayerAnimator: no se encontró el hueso '%s*'. Los brazos animarán el cuerpo entero." % UPPER_BODY_ROOT_PREFIX)
		return []

	var pending: Array[int] = [root_bone]

	while not pending.is_empty():
		var bone: int = pending.pop_back()
		upper_bones[skeleton.get_bone_name(bone)] = true
		pending.append_array(skeleton.get_bone_children(bone))

	var paths := {}

	for clip in clips:
		if not animation_player.has_animation(clip):
			continue

		var animation := animation_player.get_animation(clip)

		for track in animation.get_track_count():
			var path := animation.track_get_path(track)

			if path.get_subname_count() == 1 and upper_bones.has(String(path.get_subname(0))):
				paths[path] = true

	var result: Array[NodePath] = []
	result.assign(paths.keys())
	return result

func _fire(node_name: StringName) -> void:
	tree.set("parameters/%s/request" % node_name, AnimationNodeOneShot.ONE_SHOT_REQUEST_FIRE)
