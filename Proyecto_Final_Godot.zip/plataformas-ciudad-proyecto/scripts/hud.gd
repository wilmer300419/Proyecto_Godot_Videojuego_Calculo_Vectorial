extends CanvasLayer

# Etiqueta con el arma, el brazo y la munición, abajo a la derecha. Se crea por
# código para no tener que añadirla a cada nivel.
var weapon_label: Label

func _ready() -> void:
	weapon_label = Label.new()

	var settings: LabelSettings = $Health.label_settings.duplicate()
	settings.font_size = 26
	weapon_label.label_settings = settings
	weapon_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	weapon_label.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	weapon_label.grow_vertical = Control.GROW_DIRECTION_BEGIN

	add_child(weapon_label)
	weapon_label.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 48)

	var player = get_parent().get_node_or_null("Player")

	if player and player.has_signal("weapon_status_changed"):
		player.weapon_status_changed.connect(_on_weapon_status_changed)
		player.emit_weapon_status() # El jugador ya cargó su arma antes de que existiera esta etiqueta

func _on_health_updated(health):
	$Health.text = str(health) + "%"

func _on_weapon_status_changed(text: String) -> void:
	weapon_label.text = text
