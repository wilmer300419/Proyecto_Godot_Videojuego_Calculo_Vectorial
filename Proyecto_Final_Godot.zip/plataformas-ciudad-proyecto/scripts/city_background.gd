extends Node3D

# Ciudad cyberpunk de fondo (modelo exportado desde Blender).
# - Aplica el shader de ventanas a los edificios.
# - Desactiva las sombras de la ciudad (es solo decorado y así rinde mejor).

@export var building_material: ShaderMaterial

func _ready():
	for node in find_children("*", "MeshInstance3D", true, false):
		var mesh_instance := node as MeshInstance3D
		mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		if mesh_instance.name == "Edificios" and building_material:
			mesh_instance.material_override = building_material
