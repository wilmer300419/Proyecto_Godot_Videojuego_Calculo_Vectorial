shader_type spatial;

// Ventanas procedurales para los edificios de la ciudad de fondo.
// Usa coordenadas locales del modelo, así las ventanas escalan con la ciudad.

uniform vec3 base_color : source_color = vec3(0.02, 0.025, 0.045);
uniform vec3 warm_color : source_color = vec3(1.0, 0.62, 0.28);
uniform vec3 cool_color : source_color = vec3(0.25, 0.75, 1.0);
uniform float window_width = 2.6;
uniform float window_height = 3.4;
uniform float lit_threshold = 0.6;
uniform float emission_energy = 2.5;

varying vec3 local_pos;
varying vec3 local_normal;

float hash(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

void vertex() {
	local_pos = VERTEX;
	local_normal = NORMAL;
}

void fragment() {
	float u = (local_pos.x - local_pos.z) / window_width;
	float v = local_pos.y / window_height;
	vec2 id = floor(vec2(u, v));

	float lit = step(lit_threshold, hash(id));
	float in_u = 1.0 - step(0.28, abs(fract(u) - 0.5));
	float in_v = 1.0 - step(0.30, abs(fract(v) - 0.5));
	float side = 1.0 - step(0.5, abs(local_normal.y)); // sin ventanas en azoteas
	float mask = lit * in_u * in_v * side;

	vec3 col = mix(warm_color, cool_color, step(0.55, hash(id + vec2(7.0, 3.0))));

	ALBEDO = base_color;
	METALLIC = 0.6;
	ROUGHNESS = 0.35;
	EMISSION = col * mask * emission_energy;
}
