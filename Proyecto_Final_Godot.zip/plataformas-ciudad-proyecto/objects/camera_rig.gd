extends Node3D

# Cámara en tercera persona que sigue al jugador.
#
# Se usa en el nodo "CameraPivot" de player.tscn. La jerarquía de nodos no cambia:
#
#   CameraPivot (este script)
#   └─ SpringArm3D          ← empuja la cámara hacia el jugador si hay una pared detrás
#      └─ Camera3D
#         └─ RayCast        ← el arma dispara desde aquí (hacia donde mira la cámara)
#
# Por qué está separada del jugador:
#  - Es "top level": no hereda la rotación del jugador. Antes, al girar el
#    personaje, la cámara giraba con él y se creaba un bucle (el personaje
#    giraba para seguir a la cámara, que giraba con el personaje...).
#  - La posición se suaviza con una interpolación exponencial independiente de
#    los FPS, y se limita cuánto puede quedarse atrás para no perder al jugador.
#
# Para ajustar el comportamiento basta con seleccionar el nodo CameraPivot en
# el Inspector y cambiar los valores de abajo.

@export_subgroup("Seguimiento")
## Nodo que se sigue. Si se deja vacío se usa el nodo padre (el jugador).
@export var target: Node3D
## Altura del punto que mira la cámara, sobre el origen del jugador.
@export var height: float = 1.35
## Distancia entre el jugador y la cámara.
@export var distance: float = 4.2
## Rapidez con la que la cámara alcanza al jugador en el plano horizontal.
## Más alto = más pegada al jugador, más bajo = más suave.
@export var follow_speed_horizontal: float = 14.0
## Igual, pero en vertical. Más bajo para que los saltos no sacudan la cámara.
@export var follow_speed_vertical: float = 7.0
## Máxima distancia (en metros) que la cámara puede quedarse atrás en horizontal.
@export var max_lag_horizontal: float = 1.2
## Máxima distancia (en metros) que la cámara puede quedarse atrás en vertical.
@export var max_lag_vertical: float = 1.5

@export_subgroup("Colisión")
## Rapidez con la que la cámara se aleja de nuevo tras haber sido empujada
## por una pared. Al acercarse lo hace al instante, para no atravesarla.
@export var zoom_out_speed: float = 4.0

@export_subgroup("Control")
@export var mouse_sensitivity: float = 0.0025
@export var gamepad_sensitivity: float = 1.8
@export_range(-80.0, 0.0, 1.0) var pitch_min_degrees: float = -60.0
@export_range(0.0, 80.0, 1.0) var pitch_max_degrees: float = 45.0

@export_subgroup("Retroceso")
## Multiplica el retroceso del arma sobre la cámara. 0 = sin retroceso.
@export var recoil_scale: float = 1.0
## Rapidez con la que la cámara se recupera del retroceso.
@export var recoil_recovery_speed: float = 8.0

# Orientación que controla el jugador con el ratón / mando (en radianes).
# El movimiento del personaje se calcula a partir de "yaw".
var yaw: float = 0.0
var pitch: float = 0.0

var _recoil_pitch: float = 0.0
var _recoil_yaw: float = 0.0
var _arm_length: float = 0.0

@onready var spring_arm: SpringArm3D = $SpringArm3D

func _ready() -> void:
	if target == null:
		target = get_parent() as Node3D

	# Se separa de la transformación del jugador conservando su orientación inicial.
	var start := global_transform
	top_level = true
	global_transform = start
	yaw = global_rotation.y

	# Se procesa después de que el jugador se haya movido en este mismo frame.
	process_physics_priority = 100

	_arm_length = distance
	spring_arm.spring_length = distance

	snap_to_target()

# Coloca la cámara de golpe sobre el objetivo, sin suavizado. Útil al aparecer
# o al teletransportar al jugador.
func snap_to_target() -> void:
	if not is_instance_valid(target):
		return
	global_position = target.global_position + Vector3.UP * height
	_apply_orientation()

# Gira la vista. Lo llama el jugador con el movimiento del ratón o del mando.
func rotate_view(x_input: float, y_input: float, is_controller: bool = false, delta: float = 0.0) -> void:
	var sensitivity: float = gamepad_sensitivity * delta if is_controller else mouse_sensitivity
	yaw -= x_input * sensitivity
	pitch = clampf(pitch - y_input * sensitivity, deg_to_rad(pitch_min_degrees), deg_to_rad(pitch_max_degrees))
	_apply_orientation()

# Empuja la vista hacia arriba / hacia un lado (retroceso del arma).
# La cámara vuelve sola a su posición (ver recoil_recovery_speed).
func add_recoil(pitch_kick: float, yaw_kick: float) -> void:
	_recoil_pitch += pitch_kick * recoil_scale
	_recoil_yaw += yaw_kick * recoil_scale

func _physics_process(delta: float) -> void:
	_follow_target(delta)
	_recover_from_recoil(delta)
	_update_arm_length(delta)
	_apply_orientation()

func _follow_target(delta: float) -> void:
	if not is_instance_valid(target):
		return

	var goal: Vector3 = target.global_position + Vector3.UP * height
	var to_goal: Vector3 = goal - global_position

	# Interpolación exponencial: mismo resultado a 30, 60 o 144 FPS.
	var horizontal := Vector2(to_goal.x, to_goal.z) * (1.0 - exp(-follow_speed_horizontal * delta))
	var vertical: float = to_goal.y * (1.0 - exp(-follow_speed_vertical * delta))
	var new_position: Vector3 = global_position + Vector3(horizontal.x, vertical, horizontal.y)

	# Límite de retraso: pase lo que pase, el jugador no sale de la pantalla.
	var lag: Vector3 = goal - new_position
	var lag_horizontal := Vector2(lag.x, lag.z).limit_length(max_lag_horizontal)
	lag.y = clampf(lag.y, -max_lag_vertical, max_lag_vertical)

	global_position = goal - Vector3(lag_horizontal.x, lag.y, lag_horizontal.y)

func _recover_from_recoil(delta: float) -> void:
	var recovery: float = 1.0 - exp(-recoil_recovery_speed * delta)
	_recoil_pitch = lerpf(_recoil_pitch, 0.0, recovery)
	_recoil_yaw = lerpf(_recoil_yaw, 0.0, recovery)

# Si una pared obliga a acercar la cámara, se acerca al instante (el SpringArm3D
# ya lo hace). Cuando el obstáculo desaparece, vuelve a su distancia poco a poco
# en lugar de dar un salto brusco.
func _update_arm_length(delta: float) -> void:
	var hit_length: float = spring_arm.get_hit_length()
	if hit_length < _arm_length - 0.001:
		_arm_length = hit_length
	else:
		_arm_length = lerpf(_arm_length, distance, 1.0 - exp(-zoom_out_speed * delta))
	spring_arm.spring_length = _arm_length

func _apply_orientation() -> void:
	var final_pitch: float = clampf(pitch + _recoil_pitch, deg_to_rad(pitch_min_degrees), deg_to_rad(pitch_max_degrees))
	rotation = Vector3(final_pitch, yaw + _recoil_yaw, 0.0)
