extends Node3D

@export var player: Node3D

@export_subgroup("Health")
@export var max_health: int = 100

@export_subgroup("Disparo")
## Distancia (m) a la que el dron puede alcanzar al jugador con su disparo.
@export var attack_range: float = 8.0
## Posición del fogonazo, relativa al dron (el eje +Z es su frente). Solo se usa si
## el modelo no trae sus propias mallas de destello.
@export var muzzle_offset: Vector3 = Vector3(0, -0.85, 1.0)
@export var muzzle_flash_scale: float = 2.5

@onready var raycast = $RayCast
@onready var attack_timer = $Timer

var health: int
var time := 0.0
var target_position: Vector3
var destroyed := false

var animation_player: AnimationPlayer
var destello_derecho: Node3D
var destello_izquierdo: Node3D
var rotor_derecho: Node3D
var rotor_izquierdo: Node3D

signal defeated(enemy) # Emitted once when this enemy is destroyed, with a reference to itself (used for the victory condition)

func _ready():
	target_position = position
	raycast.target_position = Vector3(0, 0, attack_range)
	health = max_health
	
	# El modelo Enemigo.glb trae su propio AnimationPlayer con una animación de
	# flotación ("Take 001") que se repite todo el rato. Se usa "idle" si existe;
	# si no, la primera animación del modelo.
	animation_player = find_child("AnimationPlayer", true, false)
	destello_derecho = find_child("Canon_Derecho_Destello", true, false)
	destello_izquierdo = find_child("Canon_Izquierdo_Destello", true, false)
	rotor_derecho = find_child("Canon_Derecho_Rotor", true, false)
	rotor_izquierdo = find_child("Canon_Izquierdo_Rotor", true, false)
	
	if destello_derecho: destello_derecho.scale = Vector3.ZERO
	if destello_izquierdo: destello_izquierdo.scale = Vector3.ZERO
	
	if animation_player:
		var clip := ""
		
		if animation_player.has_animation("idle"):
			clip = "idle"
		else:
			for animation_name in animation_player.get_animation_list():
				if animation_name != "RESET":
					clip = animation_name
					break
		
		if clip != "":
			animation_player.get_animation(clip).loop_mode = Animation.LOOP_LINEAR
			animation_player.play(clip)
			animation_player.seek(randf() * animation_player.get_animation(clip).length) # Cada dron flota desfasado


func _process(delta):
	self.look_at(player.position + Vector3(0, 0.9, 0), Vector3.UP, true)  # Look at player
	target_position.y += (cos(time * 5) * 1) * delta  # Sine movement (up and down)

	time += delta

	position = target_position
	
	# Los cañones gatling giran todo el tiempo mientras el dron esté activo
	if rotor_derecho: rotor_derecho.rotate_z(delta * 18.0)
	if rotor_izquierdo: rotor_izquierdo.rotate_z(delta * -18.0)

# Take damage from player

func damage(amount):
	if destroyed:
		return

	Audio.play("sounds/enemy_hurt.ogg")

	health -= amount

	if health <= 0 and !destroyed:
		destroy()

# Destroy the enemy permanently once out of health (no respawn)

func destroy():
	Audio.play("sounds/enemy_destroy.ogg")

	destroyed = true
	defeated.emit(self) # Tell the level this enemy has been eliminated (used for the victory condition)

	queue_free()

# Shoot when timer hits 0

func _on_timer_timeout():
	raycast.force_raycast_update()

	if raycast.is_colliding():
		var collider = raycast.get_collider()

		if collider.has_method("damage"):  # Raycast collides with player
			
			# Fogonazo de los dos cañones (por script, no bloquea el loop "idle")
			
			if destello_derecho:
				destello_derecho.scale = Vector3.ONE * randf_range(0.85, 1.15)
			if destello_izquierdo:
				destello_izquierdo.scale = Vector3.ONE * randf_range(0.85, 1.15)
			
			if not destello_derecho and not destello_izquierdo:
				_spawn_muzzle_flash()
			
			get_tree().create_timer(0.1).timeout.connect(_reset_destellos)

			Audio.play("sounds/enemy_attack.ogg")

			collider.damage(5)  # Apply damage to player

func _reset_destellos():
	if destello_derecho: destello_derecho.scale = Vector3.ZERO
	if destello_izquierdo: destello_izquierdo.scale = Vector3.ZERO

# Fogonazo con el sprite de impacto del proyecto (el dron actual no trae destellos propios)

func _spawn_muzzle_flash():
	var flash = preload("res://objects/impact.tscn").instantiate()
	flash.play("shot")
	get_tree().root.add_child(flash)
	
	flash.global_position = global_position + global_basis * muzzle_offset
	flash.scale = Vector3.ONE * muzzle_flash_scale
	
	var camera := get_viewport().get_camera_3d()
	
	if camera:
		flash.look_at(camera.global_transform.origin, Vector3.UP, true)
