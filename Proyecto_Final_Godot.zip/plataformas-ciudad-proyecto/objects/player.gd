extends CharacterBody3D

@export_subgroup("Properties")
@export var movement_speed = 5
@export var run_speed_multiplier = 1.8
@export_range(0, 100) var number_of_jumps: int = 2
@export var jump_strength = 8

@export_subgroup("Weapons")
@export var weapons: Array[Weapon] = []
## Al apuntar (clic derecho) la dispersión de los disparos se multiplica por este valor.
@export_range(0.0, 1.0) var aim_spread_multiplier: float = 0.5

@export_subgroup("Cuerpo a cuerpo")
@export var melee_damage: float = 40.0
## Distancia (m) a la que llega el golpe, medida desde el jugador.
@export var melee_range: float = 2.4
## Segundos desde que se pulsa el ataque hasta que el golpe conecta (la animación
## alcanza su impacto a la mitad).
@export var melee_hit_delay: float = 0.5
## Segundos que dura el ataque antes de poder disparar, recargar o golpear otra vez.
@export var melee_lock_time: float = 0.9

@export_subgroup("Muerte")
## Segundos que se mantiene al personaje caído antes de mostrar la pantalla de derrota.
@export var death_screen_delay: float = 0.6

var weapon: Weapon
var weapon_index := 0

@export_subgroup("Cámara")
# Distancia, altura, suavizado, sensibilidad y límites de la cámara se ajustan
# en el nodo CameraPivot (script objects/camera_rig.gd).
@export var turn_speed: float = 10.0
## true: el cuerpo mira siempre hacia donde mira la cámara (hace falta para que se vean
## las animaciones de caminar hacia atrás o de lado). false: el cuerpo gira hacia
## donde camina (comportamiento anterior).
@export var face_camera: bool = true

var mouse_captured := true

var movement_velocity: Vector3 = Vector3.ZERO

var input_mouse: Vector2

var health: int = 100
var gravity := 0.0

var previously_floored := false

var jumps_remaining: int

var is_sprinting := false
var is_aiming := false

var is_dead := false # Guards against dying more than once (fall + damage in the same frame, etc.)

# Combate
var arm_mode: PlayerAnimator.Arm = PlayerAnimator.Arm.LEFT
var ammo: Array[int] = [] # Munición del cargador de cada arma (0 si no usa cargador)
var is_reloading := false
var is_meleeing := false

var muzzle_flash: Node3D # nodo "Arma_Muzzle_Flash" si el modelo importado lo trae

var _reload_weapon_index := 0
var _reload_queue: Array[PlayerAnimator.Arm] = []
var _melee_count := 0
var _air_animation_started := false
var _time_in_air := 0.0

static var _death_counter := 0 # Alterna Death A / Death B entre muertes (incluso al reintentar)

signal health_updated
signal died # Emitted once when the player runs out of health or falls off the level
signal weapon_status_changed(text: String) # Texto para el HUD: arma, brazo y munición

@onready var body = $Body
@onready var animator: PlayerAnimator = $PlayerAnimator
@onready var camera_rig = $CameraPivot # Script objects/camera_rig.gd
@onready var camera = $CameraPivot/SpringArm3D/Camera3D
@onready var raycast = $CameraPivot/SpringArm3D/Camera3D/RayCast
@onready var sound_footsteps = $SoundFootsteps
@onready var blaster_cooldown = $Cooldown
@onready var muzzle_flash_timer = $MuzzleFlashTimer

# Temporizadores creados por código (así player.tscn no necesita más nodos)
var reload_timer := Timer.new()
var melee_hit_timer := Timer.new()
var melee_lock_timer := Timer.new()
var death_timer := Timer.new()

@export var crosshair: TextureRect

# Functions

func _ready() -> void:
	camera.current = true
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

	for weapon_resource in weapons:
		ammo.append(weapon_resource.magazine_size)

	weapon = weapons[weapon_index] # Weapon must never be nil
	initiate_change_weapon(weapon_index)

	# Si el modelo trae una malla de fogonazo ("Arma_Muzzle_Flash") se usa; Player.glb no la trae.
	muzzle_flash = body.find_child("Arma_Muzzle_Flash", true, false)

	if muzzle_flash:
		muzzle_flash.scale = Vector3.ZERO

	muzzle_flash_timer.timeout.connect(_on_muzzle_flash_timeout)

	for timer in [reload_timer, melee_hit_timer, melee_lock_timer, death_timer]:
		timer.one_shot = true
		add_child(timer)

	reload_timer.timeout.connect(_on_reload_timeout)
	melee_hit_timer.timeout.connect(_melee_strike)
	melee_lock_timer.timeout.connect(_on_melee_finished)
	death_timer.timeout.connect(_on_death_screen_time)

	# Jump/Hop duran lo mismo que el salto físico: sube con jump_strength y baja con gravedad 20.
	animator.set_air_time(2.0 * jump_strength / 20.0)

func _physics_process(delta: float) -> void:
	handle_controls(delta)
	handle_gravity(delta)

	var desired_velocity: Vector3 = Vector3.ZERO if is_dead else movement_velocity
	var camera_yaw_basis: Basis = Basis(Vector3.UP, camera_rig.yaw)
	var horizontal_forward: Vector3 = -camera_yaw_basis.z
	var horizontal_right: Vector3 = camera_yaw_basis.x
	var move_input: Vector2 = Vector2.ZERO if is_dead else Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	if move_input.length_squared() > 0.001:
		var move_direction: Vector3 = (horizontal_right * move_input.x + horizontal_forward * -move_input.y).normalized()
		desired_velocity = move_direction * movement_speed * (run_speed_multiplier if is_sprinting else 1.0)

		if not face_camera:
			var target_yaw: float = atan2(-move_direction.x, -move_direction.z)
			var model_forward_offset: float = deg_to_rad(0.0)
			rotation.y = lerp_angle(rotation.y, target_yaw + model_forward_offset, minf(delta * turn_speed, 1.0))

	if face_camera and not is_dead:
		rotation.y = lerp_angle(rotation.y, camera_rig.yaw, minf(delta * turn_speed, 1.0))

	var applied_velocity: Vector3 = velocity.lerp(desired_velocity, minf(delta * 10.0, 1.0))
	applied_velocity.y = -gravity
	velocity = applied_velocity
	move_and_slide()

	# Movement sound

	sound_footsteps.stream_paused = true

	if is_on_floor() and not is_dead:
		if abs(velocity.x) > 1 or abs(velocity.z) > 1:
			sound_footsteps.stream_paused = false

	# Landing after jump or falling

	if is_on_floor() and gravity > 1 and !previously_floored: # Landed
		Audio.play("sounds/land.ogg")

	previously_floored = is_on_floor()

	# Animación del personaje (locomoción, apuntado, caída)

	update_animation(delta)

	# Falling/respawning

	if position.y < -10 and not is_dead:
		die(false) # Cae al vacío: pantalla de derrota directa, sin animación

# Mouse movement

func _input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and mouse_captured and not is_dead:
		handle_rotation(event.relative.x, event.relative.y, false)

func handle_controls(delta: float) -> void:
	# Mouse capture
	if Input.is_action_just_pressed("mouse_capture"):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		mouse_captured = true

	if Input.is_action_just_pressed("mouse_capture_exit"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		mouse_captured = false

		input_mouse = Vector2.ZERO

	# Con el personaje caído no se atiende ningún control
	if is_dead:
		is_sprinting = false
		is_aiming = false
		return

	# Movement
	is_sprinting = Input.is_action_pressed("sprint")
	is_aiming = Input.is_action_pressed("aim")
	movement_velocity = Vector3.ZERO

	# Handle Controller Rotation
	var rotation_input: Vector2 = Input.get_vector("camera_left", "camera_right", "camera_up", "camera_down")
	if rotation_input.length_squared() > 0.0:
		handle_rotation(rotation_input.x, rotation_input.y, true, delta)

	# Weapon / arm selection, reload and melee

	action_weapon_select()
	action_arm_select()

	if Input.is_action_just_pressed("reload"):
		start_reload()

	if Input.is_action_just_pressed("melee"):
		start_melee()

	# Shooting

	action_shoot()

	# Jumping

	if Input.is_action_just_pressed("jump"):
		if jumps_remaining:
			action_jump()

	# Weapon switching

	action_weapon_toggle()

# Camera rotation: la vista la controla el rig de la cámara (camera_rig.gd),
# que es independiente del cuerpo del jugador.

func handle_rotation(xRot: float, yRot: float, isController: bool, delta: float = 0.0) -> void:
	camera_rig.rotate_view(xRot, yRot, isController, delta)

# Handle gravity

func handle_gravity(delta):
	gravity += 20 * delta

	if gravity < 0 and is_on_ceiling():
		gravity = 0

	if gravity > 0 and is_on_floor():
		jumps_remaining = number_of_jumps
		gravity = 0

# Jumping

func action_jump():
	Audio.play("sounds/jump_a.ogg, sounds/jump_b.ogg, sounds/jump_c.ogg")

	# Primer salto = Jump. Los saltos extra en el aire (doble salto) = Hop.
	animator.play_jump(jumps_remaining < number_of_jumps)
	_air_animation_started = true

	gravity = - jump_strength
	jumps_remaining -= 1

# Shooting

func action_shoot():
	if not Input.is_action_pressed("shoot"):
		animator.release_upper() # Suelta el fuego automático de la metralleta
		return

	if is_reloading or is_meleeing:
		return # No se dispara mientras se recarga o se golpea

	if weapon.magazine_size > 0 and ammo[weapon_index] <= 0:
		start_reload() # Cargador vacío: recarga sola
		return

	if !blaster_cooldown.is_stopped(): return # Cooldown for shooting

	Audio.play(weapon.sound_shoot)

	flash_muzzle()

	blaster_cooldown.start(weapon.cooldown)

	# Con "ambos brazos" salen dos disparos por pulsación (uno por brazo)

	var arms_used: int = 2 if arm_mode == PlayerAnimator.Arm.BOTH else 1

	if weapon.magazine_size > 0:
		arms_used = mini(arms_used, ammo[weapon_index])
		ammo[weapon_index] -= arms_used

	var spread: float = weapon.spread * (aim_spread_multiplier if is_aiming else 1.0)

	# Shoot the weapon, amount based on shot count

	for n in weapon.shot_count * arms_used:
		raycast.target_position.x = randf_range(-spread, spread)
		raycast.target_position.y = randf_range(-spread, spread)

		raycast.force_raycast_update()

		if !raycast.is_colliding(): continue # Don't create impact when raycast didn't hit

		var collider = raycast.get_collider()

		# Hitting an enemy

		if collider.has_method("damage"):
			collider.damage(weapon.damage)

		# Creating an impact animation

		var impact = preload("res://objects/impact.tscn")
		var impact_instance = impact.instantiate()

		impact_instance.play("shot")

		get_tree().root.add_child(impact_instance)

		impact_instance.position = raycast.get_collision_point() + (raycast.get_collision_normal() / 10)
		impact_instance.look_at(camera.global_transform.origin, Vector3.UP, true)

	var knockback = random_vec2(weapon.min_knockback, weapon.max_knockback)
	camera_rig.add_recoil(knockback.x, knockback.y) # Knockback of camera (se recupera solo)
	movement_velocity += Vector3(0, 0, weapon.knockback) # Knockback

	# Animación de disparo en brazos/torso. La metralleta es un clip en bucle que se
	# mantiene mientras se dispara; el resto se reproduce una vez por disparo.
	animator.play_upper(PlayerAnimator.shoot_clip(weapon.weapon_type, arm_mode), weapon.weapon_type == Weapon.Type.MG)

	emit_weapon_status()

# Enciende brevemente la malla de fogonazo del arma, si el modelo la trae.

func flash_muzzle():
	if not muzzle_flash: return

	muzzle_flash.rotation_degrees.z = randf_range(-45, 45)
	muzzle_flash.scale = Vector3.ONE * randf_range(0.85, 1.15)

	muzzle_flash_timer.start()

func _on_muzzle_flash_timeout():
	if muzzle_flash:
		muzzle_flash.scale = Vector3.ZERO

# Toggle between available weapons (listed in 'weapons')

func action_weapon_toggle():
	if Input.is_action_just_pressed("weapon_toggle") and not is_reloading:
		weapon_index = wrap(weapon_index + 1, 0, weapons.size())
		initiate_change_weapon(weapon_index)

		Audio.play("sounds/weapon_change.ogg")

# Teclas 1 / 2 / 3: metralleta, revólver, escopeta

func action_weapon_select():
	if is_reloading:
		return # No se cambia de arma a mitad de una recarga

	var requested := -1

	if Input.is_action_just_pressed("weapon_mg"):
		requested = Weapon.Type.MG
	elif Input.is_action_just_pressed("weapon_revolver"):
		requested = Weapon.Type.REVOLVER
	elif Input.is_action_just_pressed("weapon_shotgun"):
		requested = Weapon.Type.SHOTGUN

	if requested == -1:
		return

	for i in weapons.size():
		if weapons[i].weapon_type == requested and i != weapon_index:
			weapon_index = i
			initiate_change_weapon(weapon_index)
			Audio.play("sounds/weapon_change.ogg")
			return

# Teclas Z / X / C: brazo izquierdo, derecho o ambos

func action_arm_select():
	if is_reloading:
		return

	if Input.is_action_just_pressed("arm_left"):
		set_arm_mode(PlayerAnimator.Arm.LEFT)
	elif Input.is_action_just_pressed("arm_right"):
		set_arm_mode(PlayerAnimator.Arm.RIGHT)
	elif Input.is_action_just_pressed("arm_both"):
		set_arm_mode(PlayerAnimator.Arm.BOTH)

func set_arm_mode(mode: PlayerAnimator.Arm) -> void:
	if arm_mode == mode:
		return

	arm_mode = mode
	animator.release_upper() # El fuego en bucle se reinicia con el brazo nuevo
	emit_weapon_status()

# Cambia de arma. El modelo visible es siempre el mismo robot: lo que cambia son las
# estadísticas (daño, cadencia, sonido, mira) y las animaciones de disparo.

func initiate_change_weapon(index):
	weapon_index = index
	change_weapon()

func change_weapon():
	weapon = weapons[weapon_index]

	# El rayo sale de la cámara, que está 'distance' metros detrás del jugador. Se suma esa
	# distancia para que max_distance sea el alcance real medido desde el personaje.
	raycast.target_position = Vector3(0, 0, -1) * (weapon.max_distance + camera_rig.distance)
	crosshair.texture = weapon.crosshair

	animator.release_upper()
	emit_weapon_status()

# Reload (solo las armas con cargador, es decir, la escopeta)

func start_reload() -> void:
	if is_dead or is_reloading or is_meleeing:
		return

	if weapon.magazine_size <= 0 or ammo[weapon_index] >= weapon.magazine_size:
		return # Sin cargador o ya lleno

	is_reloading = true
	_reload_weapon_index = weapon_index

	# Con ambos brazos se recarga primero el izquierdo y después el derecho.
	if arm_mode == PlayerAnimator.Arm.BOTH:
		_reload_queue = [PlayerAnimator.Arm.LEFT, PlayerAnimator.Arm.RIGHT]
	else:
		_reload_queue = [arm_mode]

	animator.stop_upper()
	_reload_next_arm()
	emit_weapon_status()

func _reload_next_arm() -> void:
	var clip := PlayerAnimator.reload_clip(_reload_queue.pop_front())

	animator.play_upper(clip)
	reload_timer.start(animator.get_clip_length(clip))

func _on_reload_timeout() -> void:
	if is_dead:
		return

	if not _reload_queue.is_empty():
		_reload_next_arm()
		return

	is_reloading = false
	ammo[_reload_weapon_index] = weapons[_reload_weapon_index].magazine_size
	emit_weapon_status()

# Melee

func start_melee() -> void:
	if is_dead or is_reloading or is_meleeing:
		return

	is_meleeing = true

	# Alterna las variantes A y B en cada golpe. Con ambos brazos también alterna de lado.
	var arm: PlayerAnimator.Arm = arm_mode

	if arm == PlayerAnimator.Arm.BOTH:
		arm = PlayerAnimator.Arm.LEFT if (_melee_count / 2) % 2 == 0 else PlayerAnimator.Arm.RIGHT

	animator.play_upper(PlayerAnimator.melee_clip(arm, _melee_count % 2 == 1))
	_melee_count += 1

	melee_hit_timer.start(melee_hit_delay)
	melee_lock_timer.start(melee_lock_time)

# Golpe en el momento del impacto: daña a todo lo que tenga método damage() delante.
func _melee_strike() -> void:
	if is_dead:
		return

	var shape := SphereShape3D.new()
	shape.radius = melee_range * 0.5

	var query := PhysicsShapeQueryParameters3D.new()
	query.shape = shape
	query.transform = Transform3D(Basis.IDENTITY, global_position + Vector3.UP * 0.9 - global_basis.z * melee_range * 0.55)
	query.collide_with_areas = true
	query.exclude = [get_rid()]

	for hit in get_world_3d().direct_space_state.intersect_shape(query, 8):
		var target = hit.collider

		if target != self and target.has_method("damage"):
			target.damage(melee_damage)

func _on_melee_finished() -> void:
	is_meleeing = false
	animator.stop_upper() # Recorta el final del clip (1.29 s) para poder encadenar acciones

# Reproduce la animación del personaje según su estado.
# Cuerpo: caminata en 8 direcciones (o quieto) relativa a hacia dónde mira el cuerpo.
# Brazos: apuntado, disparo, recarga, melee. Aire: Jump / Hop.

func update_animation(delta: float) -> void:
	var horizontal := Vector3(velocity.x, 0.0, velocity.z)
	var move_vector: Vector2 = Vector2(horizontal.dot(global_basis.x), horizontal.dot(-global_basis.z)) / movement_speed

	animator.update_locomotion(move_vector, is_sprinting, delta)
	animator.set_aiming(is_aiming)

	# Caída sin salto (se baja de una plataforma): tras un instante se usa la pose de salto.
	if is_on_floor():
		_time_in_air = 0.0
		_air_animation_started = false
	else:
		_time_in_air += delta

		if _time_in_air > 0.25 and not _air_animation_started and not is_dead:
			animator.play_jump(false)
			_air_animation_started = true

# Take damage

func damage(amount):
	if is_dead:
		return # Ya está caído: no se vuelve a herir ni a matar

	health -= amount
	health_updated.emit(health) # Update health on HUD

	if health < 0:
		die()

# Muerte: detiene el control, reproduce Death A / Death B (alternando) y, al acabar,
# avisa al nivel con la señal 'died' para que muestre la pantalla de derrota.

func die(play_animation := true) -> void:
	if is_dead:
		return

	is_dead = true
	collision_layer = 0 # Los enemigos dejan de dispararle a un personaje caído

	for timer in [reload_timer, melee_hit_timer, melee_lock_timer]:
		timer.stop()

	is_reloading = false
	is_meleeing = false

	if not play_animation:
		died.emit() # Let the level show the defeat screen instead of reloading directly
		return

	var length := animator.play_death(_death_counter)
	_death_counter += 1

	death_timer.start(length + death_screen_delay)

func _on_death_screen_time() -> void:
	died.emit() # Let the level show the defeat screen instead of reloading directly

# Texto del HUD con el arma, el brazo y la munición

func emit_weapon_status() -> void:
	var weapon_name: String = weapon.display_name if weapon.display_name != "" else Weapon.Type.keys()[weapon.weapon_type]
	var arm_name: String = ["IZQUIERDO", "DERECHO", "AMBOS"][arm_mode]
	var text := "%s  |  BRAZO %s" % [weapon_name, arm_name]

	if weapon.magazine_size > 0:
		text += "  |  %d / %d" % [ammo[weapon_index], weapon.magazine_size]

	if is_reloading:
		text += "  |  RECARGANDO..."

	weapon_status_changed.emit(text)

# Create a random knockback vector
static func random_vec2(_min: Vector2, _max: Vector2) -> Vector2:
	var _sign = -1 if randi() % 2 == 0 else 1
	return Vector2(randf_range(_min.x, _max.x), randf_range(_min.y, _max.y) * _sign)
