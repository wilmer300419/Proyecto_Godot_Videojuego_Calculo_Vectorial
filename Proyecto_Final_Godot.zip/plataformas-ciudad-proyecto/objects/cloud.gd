extends Node3D

var time = 0.0

var random_number = RandomNumberGenerator.new()

var random_velocity:float
var random_time:float

func _ready():
	
	random_velocity = random_number.randf_range(0.1, 2.0)
	random_time = random_number.randf_range(0.1, 2.0)
	
	# Los niveles colocan las "nubes" con rotaciones inclinadas al azar.
	# Para que el vehículo no quede boca abajo, conservamos solo el giro
	# horizontal (yaw) y una escala uniforme.
	var s: Vector3 = basis.get_scale().abs()
	var uniform_scale: float = (s.x + s.y + s.z) / 3.0
	var yaw: float = basis.orthonormalized().get_euler().y
	basis = Basis(Vector3.UP, yaw) * uniform_scale
	
	# Animación del vehículo (ruedas, cañón y balanceo), con inicio aleatorio
	var anim := find_child("AnimationPlayer", true, false) as AnimationPlayer
	if anim and anim.has_animation("Vehiculo_loop"):
		anim.get_animation("Vehiculo_loop").loop_mode = Animation.LOOP_LINEAR
		anim.play("Vehiculo_loop")
		anim.seek(random_number.randf() * anim.current_animation_length, true)

func _process(delta):
	
	position.y += (cos(time * random_time) * random_velocity) * delta # Sine movement
	
	time += delta
